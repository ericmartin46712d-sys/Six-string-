package com.sixstringbootcamp.app.ui

class MainActivity {}